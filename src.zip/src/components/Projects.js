import React from "react";
import "../styles/Projects.css";

const Projects = () => {
  return (
    <div className="projects-container">
      <h2 className="projects-title">My Projects</h2>
      <div className="projects-grid">

        {/* Snake Game */}
        <div className="project-card">
          <h3>Snake Game</h3>
          <p>
            A Python project utilizing data structures like arrays, linked lists, and trees.
            Features smooth gameplay mechanics, score tracking, and increasing difficulty levels.
          </p>
          <a
            href="https://github.com/pavankumaryadav319/snake-game"
            target="_blank"
            rel="noopener noreferrer"
            className="github-link"
          >
            View on GitHub
          </a>
        </div>

        {/* Library Management System */}
        <div className="project-card">
          <h3>Library Management System</h3>
          <p>
            A structured C++ project for managing books, issuing and returning books, 
            and tracking inventory using efficient data structures.
          </p>
          <a
            href="https://github.com/pavankumaryadav319/simple-library-management-system-"
            target="_blank"
            rel="noopener noreferrer"
            className="github-link"
          >
            View on GitHub
          </a>
        </div>

        {/* Grocery Store & Sales Management System */}
        <div className="project-card">
          <h3>Grocery Store and Sales Management System</h3>
          <p>
            A predictive machine learning model analyzing customer buying patterns, 
            helping businesses optimize inventory and maximize sales.
          </p>
          <a
            href="https://github.com/pavankumaryadav319/GROCERY-STORE-AND-SALES-MANAGEMENT-SYSTEM"
            target="_blank"
            rel="noopener noreferrer"
            className="github-link"
          >
            View on GitHub
          </a>
        </div>

        {/* EDA on Sports Performance Data */}
        <div className="project-card">
          <h3>EDA on Sports Performance Data</h3>
          <p>
            A data-driven analysis project using Python to extract key insights from sports statistics, 
            helping teams and athletes improve their performance.
          </p>
          <a
            href="https://github.com/pavankumaryadav319/cse353-"
            target="_blank"
            rel="noopener noreferrer"
            className="github-link"
          >
            View on GitHub
          </a>
        </div>

        {/* Online Real Estate Website */}
        <div className="project-card">
          <h3>Online Real Estate Platform</h3>
          <p>
            A React-based website for buying and selling properties, 
            featuring property listings, search filters, and secure payment integration.
          </p>
          <a
            href="https://github.com/pavankumaryadav319/-ONLINE-REAL-ESTATE-PLATFORM-A-WEBSITE-FOR-BUYING-LANDS-AND-RESORTS"
            target="_blank"
            rel="noopener noreferrer"
            className="github-link"
          >
            View on GitHub
          </a>
        </div>

      </div>
    </div>
  );
};

export default Projects;
