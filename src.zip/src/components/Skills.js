import React, { useState } from "react";
import "../styles/Skills.css"; // Ensure correct path

const Skills = () => {
  const [isVisible, setIsVisible] = useState(false);

  return (
    <div className="skills-container">
      <h2 className="skills-title" onClick={() => setIsVisible(!isVisible)}>
        My Skills {isVisible ? "▲" : "▼"}
      </h2>

      {isVisible && (
        <div className="skills-content">
          
            
          <ul>
            <li><strong>Languages:</strong> Python, C, C++, JAVA, SQL</li>
            <li><strong>Web Developemnt:</strong> HTML, CSS</li>
            <li><strong>Databases:</strong> MySQL,</li>
            <li><strong>Version Control:</strong> Git, GitHub</li>
            <li><strong>Problem Solving:</strong> LeetCode, Unstop</li>
            <li><strong>Soft Skills:</strong> Leadership, Teamwork, Project Management, Analytical Thinking</li>
          </ul>
         
        </div>
      )}
    </div>
  );
};

export default Skills;
