import React from "react";
import "../styles/Contact.css";

const Contact = () => {
  return (
    <div className="contact-container">
      <h2 className="contact-title">Contact Me</h2>
      <p className="contact-subtitle">
        Feel free to reach out to me for collaboration or any queries!
      </p>

      <div className="contact-info">
        <p>
          <strong>Email:</strong> yadavpavankumar319@gmail.com
        </p>
        <p>
          <strong>Phone:</strong> +91 6302343674
        </p>
        <p>
          <strong>LinkedIn:</strong>{" "}
          <a
            href="https://www.linkedin.com/in/pavan-kumar-yadav-a051a8252/
 "
            target="_blank"
            rel="noopener noreferrer"
          >
          linkedin.com/in/pavan-kumar-yadav
 
          </a>
        </p>
      </div>
    </div>
  );
};

export default Contact;
