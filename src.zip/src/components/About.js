import React from "react";
import "../styles/About.css"; // Ensure correct path
import profilePic from "../assets/deep.jpeg"; // Ensure correct path

const About = () => {
  return (
    <div className="about-container">
      <h1 className="about-title">About Me.</h1>
      <p className="about-subtitle">
        My everyday work is presented here, I do what I love.
        <br />
        Who I am, what I do, and my social networks—connect with me.
      </p>

      <div className="about-content">
        {/* Left Section: Profile Image */}
        <div className="about-image">
          <img src={profilePic} alt="Pallapati PavanKumar" />
        </div>

        {/* Right Section: About Text */}
        <div className="about-text">
          <h2>Pallapati pavankumar</h2>
          <p className="about-role">B.Tech 3rd Year | Data Science and Machine Learning</p>
          <p>
            I am Deepshikha Pal, a third-year B.Tech student at Lovely Professional University,
            specializing in Data Science and Machine Learning. Alongside my academic journey,
            I have gained hands-on experience in web development and machine learning.
          </p>
          <p>
            In my technical projects, I developed a Snake Game using Python libraries, overcoming
            challenges in graphics implementation with guidance from my seniors. Additionally, I worked
            on a Library Management System through Board Infinity, which strengthened my foundation in
            data analytics.
          </p>
          <p>
            Apart from my technical skills, I am an accomplished Kabaddi player, winning a gold medal in the
            district-level championship (Under 18) and securing the runner-up position in the Under 19 category.
          </p>
        </div>
      </div>
    </div>
  );
};

export default About;
