import React from "react";
import About from "./components/About";
import Skills from "./components/Skills";
import Projects from "./components/Projects";
import Contact from "./components/Contact";
import "./App.css";

const App = () => {
  return (
    <div>
      {/* Navigation Bar */}
      <header>
        <nav>
          <ul>
            <li><a href="#about">About</a></li>
            <li><a href="#skills">Skills</a></li>
            <li><a href="#projects">Projects</a></li>
            <li><a href="#contact">Contact</a></li>
            <li><a href="/resume.pdf" download="PavanKumar.pdf">Download Resume</a></li>
          </ul>
        </nav>
      </header>

      {/* Sections */}
      <section id="about"><About /></section>
      <section id="skills"><Skills /></section>
      <section id="projects"><Projects /></section>
      <section id="contact"><Contact /></section>

      {/* Footer */}
      <footer>
        <p>© 2025 Pallapati Pavan Kumar | All Rights Reserved</p>
      </footer>
    </div>
  );
};

export default App;
